﻿using System;
using System.IO;
using System.Text;
using TwinCAT.Ads;
using System.Timers;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Collections.Concurrent;


namespace pdms_one_csv_streamwriter_modification_v2
{
    class TraceAdsSymbol
    {
        /// <summary>instance of the ads client</summary>
        private AdsClient _adsclient = new AdsClient();
        /// <summary>ams netid</summary>
        private string _netId;
        /// <summary>ams port</summary>
        private int _port;
        /// <summary>instance of the ads symbol</summary>
        private List<AdsSymbol> _adssymbols = new List<AdsSymbol>();
        /// <summary>list of sample</summary>
        private ConcurrentQueue<Sample> _samples = new ConcurrentQueue<Sample>();

        /// <summary>list of sample</summary>
        private List<Sample> _listsamples1 = new List<Sample>();
        /// <summary>list of sample</summary>
        private List<Sample> _listsamples2 = new List<Sample>();
        /// <summary>list of sample</summary>
        private List<Sample> _listsamples3 = new List<Sample>();
        /// <summary>list of sample</summary>
        private List<Sample> _listsamples4 = new List<Sample>();
        /// <summary>list of sample</summary>
        private List<Sample> _listsamples5 = new List<Sample>();
        /// <summary>list of sample</summary>
        private List<Sample> _listsamples6 = new List<Sample>();
        /// <summary>list of sample</summary>
        private List<Sample> _listsamples7 = new List<Sample>();
        /// <summary>list of sample</summary>
        private List<Sample> _listsamples8 = new List<Sample>();

        /// <summary>sample</summary>
        private Sample _sample = new Sample();

        /// <summary>timer to stop the recording/trace</summary>
        private System.Timers.Timer _timer = new System.Timers.Timer();
        public event EventHandler Completed;
        /// <summary>stringbuilder to save samples as string</summary>
        private StringBuilder _stringbuilder = new StringBuilder();
        /// <summary>stringbuilder of the samples</summary>
        public StringBuilder stringbuilder
        {
            get { return this._stringbuilder; }
        }

        public bool global_header = true;

        /// <summary>standard contructor</summary>
        public TraceAdsSymbol() { }
        /// <summary>constructor</summary>
        /// <param name="netId">ams netid</param>
        /// <param name="port"></param>
        /// <param name="adssymbol">instance of the ads symbol</param>
        public TraceAdsSymbol(string netId, int port, List<AdsSymbol> adssymbols)
        {
            this._netId = netId;
            this._port = port;
            this._port = port;
            this._adssymbols = adssymbols;
        }

        /// <summary>start the trace and collect the samples</summary>
        /// /// <param name="time">trace time, after this time the trace is stopped</param>
        public void Start(double time)
        {
            try
            {
                // clear stringbuilder
                this._stringbuilder.Clear();

                // clear samples
                this._samples.Clear();

                Console.WriteLine(DateTime.Now.ToString() + ":\t" + "trace started...");

                // connect ads client
                this._adsclient.Connect(_netId, _port);

                if (this._adsclient.IsConnected)
                {
                    Console.WriteLine(DateTime.Now.ToString() + ":\t" + "connected to: " + "netId: " + _netId + ", port: " + _port);

                    // write header of stringbuilder
                    foreach (AdsSymbol adssymbol in _adssymbols)
                    {
                        //this._stringbuilder.AppendLine("AMS NetId: " + _netId);
                        //this._stringbuilder.AppendLine("AMS Port: " + _port);
                        //this._stringbuilder.AppendLine("Ads Variable: " + adssymbol.varname);
                        //this._stringbuilder.AppendLine("Type Ads Variable: " + adssymbol.type.Name);
                        //this._stringbuilder.AppendLine("Trace settings: " + "AdsTransMode: " + adssymbol.settings.NotificationMode + ", CycleTime: " + adssymbol.settings.CycleTime + ", MaxDelay: " + adssymbol.settings.MaxDelay);
                        //this._stringbuilder.AppendLine();
                    }

                    if (global_header == true)
                    {
                        //this._stringbuilder.AppendLine("fCurrentScaled" + ";" + "nSchneidenzahler" + ";" + "nSchritt");
                        //this._stringbuilder.AppendLine("" + ";" + "" + ";" + "");
                        global_header = false;
                    }
                    else
                    {
                        //this._stringbuilder.AppendLine("" + ";" + "" + ";" + "" );
                    }

                    //this._stringbuilder.AppendLine("sample" + ";" + "value1" + ";" + "timestamp1" + ";" + "value2" + ";" + "timestamp2" + ";" + "timedifference");


                    // add ads notification
                    AddAdsNotifications();

                    foreach (AdsSymbol adssymbol in _adssymbols)
                    {
                        Console.WriteLine(DateTime.Now.ToString() + ":\t" + "add variable to notification: " + adssymbol.varname);
                    }
                    //SetTimer(time);
                    Console.WriteLine(DateTime.Now.ToString() + ":\t" + "start timer and collect samples");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(DateTime.Now.ToString() + ":\t" + nameof(Start) + " " + ex.Message);
            }
        }

        private void SetTimer(double time)
        {
            try
            {
                // set timer intervall
                this._timer.Interval = time;
                // settings to run the event only once
                this._timer.AutoReset = false;
                this._timer.Enabled = true;
                //register the event
                this._timer.Elapsed += TimeElapsedEvent;
            }
            catch (Exception ex)
            {
                Console.WriteLine(DateTime.Now.ToString() + ":\t" + nameof(SetTimer) + " " + ex.Message);
            }

        }

        private void TimeElapsedEvent(object sender, ElapsedEventArgs e)
        {
            try
            {
                Console.WriteLine(DateTime.Now.ToString() + ":\t" + "collecting samples completed");

                // delete timer event function
                this._timer.Elapsed -= TimeElapsedEvent;

                // delete ads notification event function
                this._adsclient.AdsNotificationEx -= adsclient_AdsNotification;

                // delete ads notification handle
                foreach (AdsSymbol adssymbol in _adssymbols)
                {
                    this._adsclient.DeleteDeviceNotification(adssymbol.handle);
                }

                SamplestoString();

                // callback function/event to copy or evaluate the collected samples/data
                Completed?.Invoke(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                Console.WriteLine(DateTime.Now.ToString() + ":\t" + nameof(TimeElapsedEvent) + " " + ex.Message);
            }
        }

        /// <summary>add ads notifications and ads notification event</summary>
        private void AddAdsNotifications()
        {
            try
            {
                // add event function
                this._adsclient.AdsNotificationEx += adsclient_AdsNotification;
                // add notification handles
                foreach (AdsSymbol adssymbol in _adssymbols)
                {
                    adssymbol.handle = _adsclient.AddDeviceNotificationEx(adssymbol.varname, adssymbol.settings, null, adssymbol.type);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(DateTime.Now.ToString() + ":\t" + nameof(AddAdsNotifications) + " " + ex.Message);
            }
        }

        /// <summary>ads notification, event is fired when a new notification is pending</summary>
        /// <param name="sender">sender of the event</param>
        /// <param name="e">data of the event</param>
        private void adsclient_AdsNotification(object sender, AdsNotificationExEventArgs e)
        {
            try
            {
                if (e.Handle == _adssymbols[0].handle)
                {
                    // add sample to concurrent queue
                    this._samples.Enqueue(new Sample(e.Value, e.Handle, e.TimeStamp));
                    // save sample into list
                    Parallel.Invoke(TransformToList);
                }
                if (e.Handle == _adssymbols[1].handle)
                {
                    // add sample to concurrent queue
                    this._samples.Enqueue(new Sample(e.Value, e.Handle, e.TimeStamp));
                    // save sample into list
                    Parallel.Invoke(TransformToList);
                }
                if (e.Handle == _adssymbols[2].handle)
                {
                    // add sample to concurrent queue
                    this._samples.Enqueue(new Sample(e.Value, e.Handle, e.TimeStamp));
                    // save sample into list
                    Parallel.Invoke(TransformToList);
                }
                if (e.Handle == _adssymbols[3].handle)
                {
                    // add sample to concurrent queue
                    this._samples.Enqueue(new Sample(e.Value, e.Handle, e.TimeStamp));
                    // save sample into list
                    Parallel.Invoke(TransformToList);
                }
                if (e.Handle == _adssymbols[4].handle)
                {
                    // add sample to concurrent queue
                    this._samples.Enqueue(new Sample(e.Value, e.Handle, e.TimeStamp));
                    // save sample into list
                    Parallel.Invoke(TransformToList);
                }
                if (e.Handle == _adssymbols[5].handle)
                {
                    // add sample to concurrent queue
                    this._samples.Enqueue(new Sample(e.Value, e.Handle, e.TimeStamp));
                    // save sample into list
                    Parallel.Invoke(TransformToList);
                }
                if (e.Handle == _adssymbols[6].handle)
                {
                    // add sample to concurrent queue
                    this._samples.Enqueue(new Sample(e.Value, e.Handle, e.TimeStamp));
                    // save sample into list
                    Parallel.Invoke(TransformToList);
                }
                if (e.Handle == _adssymbols[7].handle)
                {
                    // add sample to concurrent queue
                    this._samples.Enqueue(new Sample(e.Value, e.Handle, e.TimeStamp));
                    // save sample into list
                    Parallel.Invoke(TransformToList);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(DateTime.Now.ToString() + ":\t" + nameof(adsclient_AdsNotification) + " " + ex.Message);
            }
        }

        /// <summary>write samples into lists</summary>
        private void TransformToList()
        {
            try
            {
                while (_samples.TryDequeue(out _sample))
                {
                    if (_sample.handle == _adssymbols[0].handle)
                    {
                        //write samples into list
                        this._listsamples1.Add(_sample);
                    }

                    if (_sample.handle == _adssymbols[1].handle)
                    {
                        //write samples into list
                        this._listsamples2.Add(_sample);
                    }

                    if (_sample.handle == _adssymbols[2].handle)
                    {
                        //write samples into list
                        this._listsamples3.Add(_sample);
                    }
                    if (_sample.handle == _adssymbols[3].handle)
                    {
                        //write samples into list
                        this._listsamples4.Add(_sample);
                    }
                    if (_sample.handle == _adssymbols[4].handle)
                    {
                        //write samples into list
                        this._listsamples5.Add(_sample);
                    }
                    if (_sample.handle == _adssymbols[5].handle)
                    {
                        //write samples into list
                        this._listsamples6.Add(_sample);
                    }
                    if (_sample.handle == _adssymbols[6].handle)
                    {
                        //write samples into list
                        this._listsamples7.Add(_sample);
                    }
                    if (_sample.handle == _adssymbols[7].handle)
                    {
                        //write samples into list
                        this._listsamples8.Add(_sample);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(DateTime.Now.ToString() + ":\t" + nameof(TransformToList) + " " + ex.Message);
            }
        }

        public void SamplestoString()
        {
            try
            {
                int countList1 = _listsamples1.Count;
                int countList2 = _listsamples2.Count;
                int countList3 = _listsamples3.Count;
                int countList4 = _listsamples4.Count;
                int countList5 = _listsamples5.Count;
                int countList6 = _listsamples6.Count;
                int countList7 = _listsamples7.Count;
                int countList8 = _listsamples8.Count;
                int countMax = Math.Max(Math.Max(Math.Max(Math.Max(Math.Max((Math.Max(Math.Max(countList1, countList2), countList3)), countList4), countList5), countList6), countList7), countList8);

                for (int i = 0; i < (countMax - 1); i++)
                {
                    string val1 = i < countList1 ? _listsamples1[i].value.ToString() : "0";
                    string val2 = i < countList2 ? _listsamples2[i].value.ToString() : "0";
                    string val3 = i < countList3 ? _listsamples3[i].value.ToString() : "0";
                    string val4 = i < countList4 ? _listsamples4[i].value.ToString() : "0";
                    string val5 = i < countList5 ? _listsamples5[i].value.ToString() : "0";
                    string val6 = i < countList6 ? _listsamples6[i].value.ToString() : "0";
                    string val7 = i < countList7 ? _listsamples7[i].value.ToString() : "0";
                    string val8 = i < countList8 ? _listsamples8[i].value.ToString() : "0";
                    this._stringbuilder.AppendLine( val1 + "," +
                                                    val2 + "," +
                                                    val3 + "," +
                                                    val4 + "," +
                                                    val5 + "," +
                                                    val6 + "," +
                                                    val7 + "," +
                                                    val8);
                    // previously, it was ;

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(DateTime.Now.ToString() + ":\t" + nameof(SamplestoString) + " " + ex.Message);
            }
        }

        /// <summary>release resources</summary>
        public void Dispose()
        {
            try
            {

                // delete ads notification event function
                this._adsclient.AdsNotificationEx -= adsclient_AdsNotification;

                // delete ads notification handle
                foreach (AdsSymbol adssymbol in _adssymbols)
                {
                    this._adsclient.DeleteDeviceNotification(adssymbol.handle);
                }

                // release resources
                this._adsclient.Dispose();
            }
            catch (Exception ex)
            {
                Console.WriteLine(DateTime.Now.ToString() + ":\t" + nameof(Dispose) + " " + ex.Message);
            }
        }
    }

    /// <summary>class adssymbol</summary>
    public class AdsSymbol
    {
        /// <summary>Full-Name of the ads variable</summary>
        public string varname;
        /// <summary>type of the ads variable</summary>
        public Type type;
        /// <summary>handle of the ads variable</summary>
        public uint handle;
        /// <summary>notification settings of the ads variable</summary>
        public NotificationSettings settings;

        /// <summary>standard contructor</summary>
        public AdsSymbol() { }
        /// <summary>constructor</summary>
        /// <param name="varname">Full-Name of the ads variable</param>
        /// <param name="type">type of the ads variable</param>
        /// <param name="handle">handle of the ads variable</param>
        /// <param name="settings">notification settings of the ads variable</param>
        public AdsSymbol(string varname, Type type, uint handle, NotificationSettings settings)
        {
            this.varname = varname;
            this.type = type;
            this.handle = handle;
            this.settings = settings;
        }
    }

    /// <summary>class sample</summary>
    public class Sample
    {
        /// <summary>value of the sample</summary>
        public object value;
        /// <summary>handle of the sample</summary>
        public uint handle;
        /// <summary>timestamp of the sample</summary>
        public DateTimeOffset timestamp;

        /// <summary>standard contructor</summary>
        public Sample() { }
        /// <summary>constructor</summary>
        /// <param name="value">value of the sample</param>
        /// <param name="timestamp">timestamp of the sample</param>
        public Sample(object value, uint handle, DateTimeOffset timestamp)
        {
            this.value = value;
            this.handle = handle;
            this.timestamp = timestamp;
        }
    }

}
