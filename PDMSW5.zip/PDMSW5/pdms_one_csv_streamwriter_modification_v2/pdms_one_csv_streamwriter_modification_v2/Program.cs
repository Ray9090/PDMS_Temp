﻿using System;
using System.IO;
using TwinCAT.Ads;
using System.Text;
using IronPython;
using System.Threading;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Collections.Generic;

// PDMSW5
namespace pdms_one_csv_streamwriter_modification_v2
{
    class Program
    {
        static string netId = "169.254.24.40.1.1";
        // static string netId = "127.0.0.1.1.1";
        static int port = (int)AmsPort.PlcRuntime_851;

        // desktop path of the .csv file to save the samples
        static string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop).ToString(), "test.csv");
        static string mpath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop).ToString(), "main.csv");

        // ads symbol symbols for which the samples are collected
        static AdsSymbol adssymbol5 = new AdsSymbol("GVL_Datalogger.St_35_VAR.fCurrentScaled", typeof(double), 0, new NotificationSettings(AdsTransMode.Cyclic, 1, 0));
        static AdsSymbol adssymbol7 = new AdsSymbol("GVL_Datalogger.St_35_VAR.nSchneidenzahler", typeof(int), 0, new NotificationSettings(AdsTransMode.Cyclic, 1, 0));
        static AdsSymbol adssymbol4 = new AdsSymbol("GVL_Datalogger.St_35_VAR.fActPos", typeof(double), 0, new NotificationSettings(AdsTransMode.Cyclic, 1, 0));
        static AdsSymbol adssymbol6 = new AdsSymbol("GVL_Datalogger.St_35_VAR.fSetPos", typeof(double), 0, new NotificationSettings(AdsTransMode.Cyclic, 1, 0));
        static AdsSymbol adssymbol2 = new AdsSymbol("GVL_Datalogger.St_35_VAR.bInPos", typeof(bool), 0, new NotificationSettings(AdsTransMode.Cyclic, 1, 0));
        static AdsSymbol adssymbol3 = new AdsSymbol("GVL_Datalogger.St_35_VAR.bRefStart", typeof(bool), 0, new NotificationSettings(AdsTransMode.Cyclic, 1, 0));
        static AdsSymbol adssymbol8 = new AdsSymbol("GVL_Datalogger.St_35_VAR.nSchritt", typeof(short), 0, new NotificationSettings(AdsTransMode.Cyclic, 1, 0));
        static AdsSymbol adssymbol1 = new AdsSymbol("GVL_Datalogger.St_35_VAR.nSysTime_SPS", typeof(ulong), 0, new NotificationSettings(AdsTransMode.Cyclic, 1, 0));


        static List<AdsSymbol> adssymbols = new List<AdsSymbol>();

        // object to collect data and start a measurement using a ads symbol
        static TraceAdsSymbol trace = null;

        //string pythonScriptPath = "real_test_2_variables.py";
        static bool traceDone = false;

        static int counter = 0;

        static void Main(string[] args)
        {
            // Start reading data
            start_read_data();

            // Wait for trace Done
            while (!traceDone)
            {
                // WriteDataToCSV - can be parallel
                WriteDataToCSV();
                Thread.Sleep(60000*240);
                // read python responce - can be parallel
                // Thread.Sleep(10000);
                pdms_py(mpath);
                Thread.Sleep(60000*10);
                counter++;
                Console.WriteLine("Minutes: " + counter*240);

            }
            trace.Dispose();
        }


        static void start_read_data()
        {
            try
            {
                adssymbols.Add(adssymbol1);
                adssymbols.Add(adssymbol2);
                adssymbols.Add(adssymbol3);
                adssymbols.Add(adssymbol4);
                adssymbols.Add(adssymbol5);
                adssymbols.Add(adssymbol6);
                adssymbols.Add(adssymbol7);
                adssymbols.Add(adssymbol8);

                trace = new TraceAdsSymbol(netId, port, adssymbols);
                // Start trace
                Console.WriteLine(DateTime.Now.ToString() + ":\t");
                trace.Start(60000*240);
            }
            catch(Exception ex)
            {
                Console.WriteLine(DateTime.Now.ToString() + "Error in trace start: "
                    + ex.Message);
            }
        }

        // sending the main csv file to python script
        static void pdms_py(string mpath)
        {
            string pythonPath = @"C:/Program Files/Python311/python.exe";
            string scriptPath = @"C:/Users/Administrator/Desktop/PDMSW5/pdms_one_csv_streamwriter_modification_v2/pdms_one_csv_streamwriter_modification_v2/Model.py";
            string arguments = mpath;

            // Create a new process start info object
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = pythonPath;
            startInfo.Arguments = scriptPath;
            startInfo.RedirectStandardError = true; // Redirect error output
            startInfo.RedirectStandardOutput = true;
            startInfo.UseShellExecute = false;
            startInfo.CreateNoWindow = false;

            using (Process process = Process.Start(startInfo))
            {
                using (StreamReader reader = process.StandardOutput)
                {
                    string result = reader.ReadToEnd().Trim();
                    Console.WriteLine("Python read result: " + result);
                    //if(result.ToLower().Contains("yes"))
                    //{
                        //traceDone = true; // Stop the trace
                    Console.WriteLine("Py is called");
                    //}
                }

            }
        }

        /// <summary>event is fired by the trace object when the specified time has elapsed</summary>
        /// <param name="sender">sender of the event</param>
        /// <param name="e">data of the event</param>
        static void WriteDataToCSV()
        {
            try
            {
                // stringbuilder to copy collected data
                StringBuilder stringbuilder = new StringBuilder();

                // copy stringbuilder
                trace.SamplestoString();
                stringbuilder = trace.stringbuilder;

                // save stringbuilder as string in csv-file on the desktop
                using (StreamWriter writer = new StreamWriter(path, true))
                {
                    writer.Write(stringbuilder.ToString());
                    writer.Flush();
                    //Console.WriteLine("Temp Flush Done");
                }

                // Read the contents of the source file
                string fileContents = File.ReadAllText(path);

                // write it to new file
                using (StreamWriter sw = new StreamWriter(mpath, true))
                {
                    sw.Write(fileContents);
                    sw.Flush();
                    //Console.WriteLine("Main Flush Done");
                }

                // clean the source file
                using (StreamWriter sw = new StreamWriter(path))
                {
                    sw.Write(string.Empty);
                    //Console.WriteLine("Temp CSV is empty");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occurred: " + ex.Message);
                // add additional debug statements to help identify the issue
            }
        }
    }
}
