
from itertools import groupby

import joblib
import polars as pl
import csv
import os
import glob
import pandas as pd
import sys
from pathlib import Path



class Prediction:
    def __init__(self, filepath):
        self.filepath = filepath
        

    def load_data(self):
        # In first 5-7 rows of raw data there is no useful value, after those rows is header,
        # after header may be there are also 1-2 rows null
        with open(self.filepath) as csv_file:
            row = csv.reader(csv_file, delimiter=',')
            # Here we use 'fCurrentScaled' as unique value to find the header
            # Read each row and find if there is 'fCurrentScaled' in this row, if yes, then this row is header
            header_ini = next(row)
            while 'fCurrentScaled' not in header_ini:
                header_ini = next(row)
            print(header_ini)
        print('csv is reading')
        # We don't need all columns, here are all columns what we will select
        u_col = ['fCurrentScaled', 'nSchneidenzahler', 'nSchritt']

        df_nschritt520_550 = pl.scan_csv(self.filepath,
                                         has_header=True,
                                         ignore_errors=True,
                                         with_column_names=lambda col: [col for col in header_ini]) \
            .select(u_col) \
            .filter(pl.col('nSchritt').is_between(0, 999)).collect().to_pandas()
        print('preprocessed done')
        return df_nschritt520_550


# have use load_data function any where but may be will use later

    def prediction_model(self):
        # find model's path in one folder
        # model_path = sorted(glob.glob("Desktop/*.save"))[0]
        # model_path = sorted(glob.glob("C:/Users/Q610267/source/repos/pdms_one_csv_streamwriter_modification_v2/pdms_one_csv_streamwriter_modification_v2/*.save"))[0]
        model_path = sorted(glob.glob("model.save"))[0]
        print('model path got it')

        # load this model
        model = joblib.load(model_path)
        print('model loaded')

        # read data from filepath
        col_Names = ['fCurrentScaled', 'nSchneidenzahler', 'nSchritt']
        new_data = pd.read_csv(self.filepath, delimiter=';', skiprows=1, names=col_Names)
        #new_data['fCurrentScaled'] = new_data['fCurrentScaled'].apply(lambda x: str(x))
        print('CSV file loaded')
        new_data = new_data.fillna(method="ffill")
        new_data['fCurrentScaled'] = new_data['fCurrentScaled'].astype('string')
        new_data['fCurrentScaled'] = new_data['fCurrentScaled'].apply(lambda x: x.replace(',', '.'))
        new_data['fCurrentScaled'] = new_data['fCurrentScaled'].astype('float')



        print(new_data['fCurrentScaled'].dtype)
        print(new_data['nSchneidenzahler'].dtype)
        print(new_data['nSchritt'].dtype)

        #new_data = load_data(filepath)
        #new_data = new_data.fillna(method="ffill")

        # select feature
        X_v = new_data[['fCurrentScaled']]
        print('feature selected')

        # predict label of this data
        predict = model.predict(X_v)
        print('predict the failure')

        # if the number of label 1 greater than 50%, print 'Yes', otherwise 'No'
        #print('yes')
        if sum(i == 1 for i in predict) / len(X_v) * 100 > 50:
            print('yes')     
        else:
            print('no')
        
  
           
if __name__ == "__main__":
    a = Prediction(r"Desktop\main.csv")
    a.prediction_model()
        

# pred = Prediction("C:/Users/HristoPC/Desktop/main.csv")

#pred = Prediction("C:/Users/Q610267/Desktop/main.csv")
#pred.prediction()