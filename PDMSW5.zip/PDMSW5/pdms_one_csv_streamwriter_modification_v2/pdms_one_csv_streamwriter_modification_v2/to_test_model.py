import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_error, r2_score
import joblib
from itertools import groupby
import joblib
import polars as pl
import csv
import os
import glob
import pandas as pd
import sys
from pathlib import Path


class Prediction:

    def __init__(self, filepath):
            self.filepath = filepath


    def prediction_model(self):

        # Load the saved model
        model_path = sorted(glob.glob("C:/Users/Q610267/Desktop/PDMS_Working/pdms_one_csv_streamwriter_modification_v2/pdms_one_csv_streamwriter_modification_v2/trained_model.joblib"))[0]
        print('model path got it')
        model = joblib.load(model_path)
        print('Model loaded')

        # Load the new dataset for testing
        # The CSV file should have columns: 'current', 'cut_number'
        # new_data = pd.read_csv(r"G:\Model_TestData\st30_ref05.csv")

        # read data from filepath
        col_Names = ['fCurrentScaled', 'nSchneidenzahler', 'nSchritt']
        new_data = pd.read_csv(self.filepath, delimiter=';', skiprows=1, names=col_Names)
        #new_data['fCurrentScaled'] = new_data['fCurrentScaled'].apply(lambda x: str(x))
        print('CSV file loaded')
        new_data = new_data.fillna(method="ffill")
        new_data['fCurrentScaled'] = new_data['fCurrentScaled'].astype('string')
        new_data['fCurrentScaled'] = new_data['fCurrentScaled'].apply(lambda x: x.replace(',', '.'))
        new_data['fCurrentScaled'] = new_data['fCurrentScaled'].astype('float')
        print('Variable type convertion done')

        # 'fCurrentScaled', 'nSchneidenzahler', 'nSchritt'
        # Extract features and target from the new dataset
        X_new = new_data[['fCurrentScaled']]
        y_new = new_data['nSchneidenzahler']

        # Predict cut_number using the loaded model
        y_pred_new = model.predict(X_new)

        # Calculate the model's performance on the new dataset
        mse_new = mean_squared_error(y_new, y_pred_new)
        r2_new = r2_score(y_new, y_pred_new)

        print(f'Mean Squared Error (new data): {mse_new}')
        print(f'R-squared Score (new data): {r2_new}')

        # Calculate the Remaining Useful Life for each data point in the new dataset
        max_cut_number = new_data['fCurrentScaled'].max()
        rul_prediction_new = abs(max_cut_number - y_pred_new)

        print(f'Remaining Useful Life (new data): {min(rul_prediction_new)}')


if __name__ == "__main__":
    a = Prediction(r"C:\Users\Q610267\Desktop\main.csv")
    a.prediction_model()
