# -*- coding: utf-8 -*-
# @Created on   : 07.03.2023 18:40
# @Author       : Q607653
# @File         : Model.py
# @Software     : PyCharm

import pickle
import csv
import numpy as np
import pandas as pd
import warnings
import imblearn

# I imported fe more lib incase I need later
from sklearn.metrics import mean_squared_error, r2_score
import joblib
from itertools import groupby
import polars as pl
import os
import glob
import sys
from pathlib import Path

warnings.filterwarnings("ignore")
#data = pd.read_csv(r"C:\Users\Q610267\Desktop\main.csv")
class Prediction:

    def __init__(self, filepath):
            self.filepath = filepath

    def create_resort_cut_number_from0(data):
        # Resort the cut number from 0, cycle1,2
        list_cut = data.nSchneidenzahler.tolist()

        resort_cut = [0]
        cut_number = 0
        for cut in range(len(list_cut) - 1):
            if list_cut[cut] == list_cut[cut + 1]:
                resort_cut.append(cut_number)
            else:
                resort_cut.append(cut_number + 1)
                cut_number += 1

        #print('Python funtion 1 called')
        return resort_cut


    def filter_current0(data):
        # Delete cuts with all current = 0
        data['cn'] = Prediction.create_resort_cut_number_from0(data)
        current_mean = data.groupby(by='cn', as_index=False).agg({'fCurrentScaled': 'mean'})
        no_cn = current_mean[current_mean.fCurrentScaled == 0].cn.tolist()
        data = data[~data['cn'].isin(no_cn)]
        data = data.reset_index(drop=True)  # After remove rows, index need to be reset
        #print('Python funtion 2 called')
        return data


    def filter_uncompleted_cut(data):
        # Select the cuts which has step:530
        groups = data.groupby('nSchneidenzahler')
        pseudocut_number = data['nSchneidenzahler'].loc[data['nSchneidenzahler'].diff().fillna(1) != 0]
        schritten = [530, 550]
        uncompleted_schneidenzhaler = []
        for ind in pseudocut_number:
            group = groups.get_group(ind)['nSchritt']
            for schritt in schritten:
                if schritt not in group.values:
                    uncompleted_schneidenzhaler = uncompleted_schneidenzhaler + [ind]
                else:
                    continue
        data = data[~data['nSchneidenzahler'].isin(uncompleted_schneidenzhaler)]
        #print('Python funtion 3 called')
        return data


    def cal_slope(data):
        current_begin = data.fCurrentScaled.iat[0]
        current_end = data.fCurrentScaled.max()
        time_begin = data.time.min()
        time_end = data[data.fCurrentScaled >= current_end].time.min()

        return np.round((current_end - current_begin) / (time_end - time_begin), 3)
        #print('Python funtion 4 called')


    def MaxJump(dataframe, numberofpoints=1, limit=0.02):
        dataframe = dataframe.reset_index(drop=True)
        local_dataframe = dataframe.loc[dataframe['fActPos'] <= 0.05].copy()
        if len(local_dataframe) == 0:
            return pd.Series()
        current_dataframe = dataframe.loc[dataframe['bInPos'] == 1].copy()
        local_dataframe['jump'] = local_dataframe['fActPos'].diff(periods=-numberofpoints)
        main_current = dataframe['fCurrentScaled'].max()

        meancurrent_list = current_dataframe['fCurrentScaled'].mean()
        maxcurrent_list = current_dataframe['fCurrentScaled'].max()
        mincurrent_list = current_dataframe['fCurrentScaled'].min()
        sumcurrent_list = current_dataframe['fCurrentScaled'].sum()
        maxjump_list = local_dataframe['jump'].max()

        if local_dataframe['jump'].max() > limit:
            if dataframe['fActPos'][local_dataframe['jump'].idxmax() - 1] > 0:
                index_list = local_dataframe['jump'].idxmax()
            elif len(local_dataframe[local_dataframe['fActPos'] < 0]) > 0:
                first_neg_index = local_dataframe[local_dataframe['fActPos'] < 0].index.tolist()[0]
                index_list = first_neg_index - 1
            else:
                index_list = local_dataframe['fActPos'].idxmin() - 1
        elif dataframe['fActPos'][local_dataframe['jump'].idxmax() - 1] > 0:
            index_list = local_dataframe['jump'].idxmax()
        elif len(local_dataframe[local_dataframe['fActPos'] < 0]) > 0:
            first_neg_index = local_dataframe[local_dataframe['fActPos'] < 0].index.tolist()[0]
            index_list = first_neg_index - 1
        else:
            index_list = local_dataframe['fActPos'].idxmin() - 1
        time_list = dataframe['Name'][index_list]
        sumposition_list = current_dataframe['fActPos'].sum()
        meanposition_list = current_dataframe['fActPos'].mean()
        # Creating Dataframe from dictionary
        d = {'indexinSingleCut': index_list, 'time_MaxJump': time_list, 'meanCurrent': meancurrent_list,
             'maxCurrent': maxcurrent_list, 'minCurrent': mincurrent_list, 'maxJump': maxjump_list,
             'sumCurrent': sumcurrent_list, 'sumposition': sumposition_list, 'meanPosition': meanposition_list,
             'mainMaxCurrent': main_current}
        return pd.Series(d)
        #print('Python funtion 5 called')


    def run_gen_feature_timediff(data, threshold=0.02):
        # Filter the data once instead of twice
        data1 = data.loc[data.fSetPos <= 1.3].reset_index(drop=True)

        # Use pandas series instead of apply function for MaxJump2
        maxJump_df = data1.groupby('cn').apply(lambda x: Prediction.MaxJump(x, limit=threshold)).reset_index()

        # Use loc function instead of isin function for indexing
        new_features = data1.loc[data1['cn'].isin(maxJump_df['cn'])].groupby('cn').apply(lambda x: pd.Series({
            'fsetpos005': x.loc[x.fSetPos <= 0.05, 'Name'].iat[0],
            'binpos1': x.loc[x.bInPos == 1, 'Name'].iat[0],
            'factpos005': x.loc[x.fActPos <= 0.05, 'Name'].iat[0],
            'fsetpos005_len': len(x.loc[x.fSetPos <= 0.05])
        })).reset_index()

        # Create the new features directly in a dataframe without using intermediate variables
        df = pd.DataFrame({
            'fsetpos005_to_jump': (maxJump_df['time_MaxJump'] - new_features['fsetpos005']) / 10000,
            'fsetpos005_to_binpos1': (new_features['binpos1'] - new_features['fsetpos005']) / 10000,
            'fsetpos005_to_factpos005': (new_features['factpos005'] - new_features['fsetpos005']) / 10000,
            'fsetpos005_to_fsetpos005': new_features['fsetpos005_len']
        })

        # Replace 0 values with the last non-zero value using pandas fillna function
        df = df.replace(0, method='ffill')
        print('Python funtion 6 called')
        return df
    

    def get_smooth(data):
        r1 = 800
        combi = data.rolling(window=r1, min_periods=0)[
                    ['fCurrentScaled', 'time', 'slope', 'fsetpos005_to_jump', 'fsetpos005_to_binpos1',
                     'fsetpos005_to_factpos005', 'fsetpos005_to_fsetpos005']].agg(
            ['min', 'max', 'mean', 'median', 'sum', 'std'])[r1:]

        combi.columns = ["_".join(a) for a in combi.columns]

        features = pd.concat([
            combi['fCurrentScaled_mean'], combi['time_mean'], combi['slope_mean'], combi['fsetpos005_to_jump_mean'],
            combi['fsetpos005_to_binpos1_mean'], combi['fsetpos005_to_factpos005_mean'],
            combi['fsetpos005_to_fsetpos005_mean']
        ], axis=1)

        features.columns = ['fCurrentScaled', 'time', 'slope', 'fsetpos005_to_jump', 'fsetpos005_to_binpos1',
                            'fsetpos005_to_factpos005', 'fsetpos005_to_fsetpos005']
        print('Python funtion 7 called')
        return features


    def Preprocessing(file_load_path):

        col_Names = ['Name', 'bInPos', 'bRefStart', 'fActPos', 'fCurrentScaled', 'fSetPos', 'nSchneidenzahler',
                     'nSchritt']
        #df = pd.read_csv(r"C:\Users\Q610267\Desktop\main.csv", delimiter=';', skiprows=1, names=col_Names)
        df = pd.read_csv(file_load_path, delimiter=',', skiprows=1, names=col_Names)

        # convert column data type
        df = df.fillna(method="ffill")
        df['fCurrentScaled'] = df['fCurrentScaled'].astype('string')
        df['fCurrentScaled'] = df['fCurrentScaled'].apply(lambda x: x.replace(',', '.'))
        df['fCurrentScaled'] = df['fCurrentScaled'].astype('float')

        df['fActPos'] = df['fActPos'].astype('string')
        df['fActPos'] = df['fActPos'].apply(lambda x: x.replace(',', '.'))
        df['fActPos'] = df['fActPos'].astype('float')

        df['fSetPos'] = df['fSetPos'].astype('string')
        df['fSetPos'] = df['fSetPos'].apply(lambda x: x.replace(',', '.'))
        df['fSetPos'] = df['fSetPos'].astype('float')

        df['Name'] = df['Name'].astype('string')
        df['Name'] = df['Name'].apply(lambda x: x.replace(',', '.'))
        df['Name'] = df['Name'].astype('float')

        df['bInPos'] = df['bInPos'].astype('bool')
        df['bRefStart'] = df['bRefStart'].astype('bool')

        print('Variable type convertion done')

        # find the header
        with open(df) as csv_file:
            row = csv.reader(csv_file, delimiter=',')
            # Here we use 'fActPos' as unique value to find the header
            # Read each row and find if there is 'fActPos' in this row, if yes, then this row is header
            header_ini = next(row)
            while 'fActPos' not in header_ini:
                header_ini = next(row)

        # Use pandas to read csv file

        df = pd.read_csv(df, skiprows=10)
        df.columns = header_ini

        # select nSchritt in 520–550
        df = df.query("520 <= nSchritt <= 550")

        # used columns
        u_col = ['Name', 'bInPos', 'bRefStart', 'fActPos', 'fCurrentScaled', 'fSetPos', 'nSchneidenzahler', 'nSchritt']
        df = df[u_col]

        # convert column datatype
        df['fCurrentScaled'] = df['fCurrentScaled'].str.replace(',', '.').astype('float')

        # sort values with 'Name'
        df = df.sort_values('Name')

        # resort number of cut
        df['cn'] = Prediction.create_resort_cut_number_from0(df)

        # calculate duration of each cut
        df['time'] = df.groupby(by='cn')['Name'].transform(lambda x: (x - x.min()) / 10000)

        # delete cut which take too much time
        long_cut = df.groupby(by='cn')['time'].max()
        long_cut = long_cut[(long_cut > 300) & (long_cut < 140)].index.tolist()
        df = df[~df.cn.isin(long_cut)]

        # delete Nan
        df = df.dropna(how='any').reset_index(drop=True)

        # delete uncompleted cuts
        df = Prediction.filter_uncompleted_cut(df).reset_index(drop=True)

        # delete cut which current value only recorded as 0
        df = Prediction.filter_current0(df)

        # resort number of cut again
        df['cn'] = Prediction.create_resort_cut_number_from0(df)

        # select fAcutPos < 0.05 and 0.1 < fCurrentScaled < 10
        df = df.query("fActPos < 0.05 and 0.1 < fCurrentScaled < 10")

        # generate features
        df_gen1 = df.groupby('cn').agg({
            'fCurrentScaled': 'sum',
            'time': 'max'})
        df_gen1['slope'] = df.groupby('cn').apply(Prediction.cal_slope)

        timediff_4 = Prediction.run_gen_feature_timediff(df)

        merged_df = pd.merge(df_gen1, timediff_4, left_index=True, right_index=True)
        merged_df = Prediction.get_smooth(merged_df)

        #print('Python funtion 8 called')
        return merged_df


    def Prediction(data):
        # load model
        loaded_model = pickle.load(open("C:/Users/Q610267/Desktop/PDMSW2/pdms_one_csv_streamwriter_modification_v2/pdms_one_csv_streamwriter_modification_v2/finalized_model.save", 'rb'))
        print('Model is loaded')
        u_cols = ['fCurrentScaled', 'fsetpos005_to_jump', 'slope']
        X = data[u_cols].values
        pred = loaded_model.predict(X)
        result = round((pred == 1).sum() / len(pred) * 100, 2)
        #print('Python funtion 9 called: This is the main and last prediction function')
        print(result)
        return round((pred == 1).sum() / len(pred) * 100, 2)


if __name__ == "__main__":
    a = Prediction(r"C:\Users\Q610267\Desktop\main.csv")
    #a = Prediction(r"C:\Users\Desktop\temp\main.csv")
    a.Prediction()
